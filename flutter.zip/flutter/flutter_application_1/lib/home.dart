import 'package:flutter/material.dart';

                              // // class home extends StatelessWidget {
                              // //   const home({super.key});


                              // //   @override
                              // //   Widget build(BuildContext context) {
                              // //     return const Material(
                              // //       child: Centre(child : Text("Home"),)
                              // //     );
                              // //   }
                              // // }
                              // class Home extends StatelessWidget {
                              //   const Home({super.key});

                              //   @override
                              //   Widget build(BuildContext context) {
                              //     return const Material(
                              //       child: Column(children: const[
                                      
                              //       ],)
                              //     );
                              //   }
                              // 
                              class Home extends StatefulWidget {
                                const Home({super.key});
                              
                                @override
                                State<Home> createState() => _HomeState();
                              }
                              
      
class _HomeState extends State<Home>{
  int val=0;
   @override 
  Widget build(BuildContext context){
    return Material(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text("Value is : $val"),
        ElevatedButton(onPressed: (){
         val=val+1;
         setState(() {});
        }, child: const Text("Press"))
      ],
    ),
    );
  }
}
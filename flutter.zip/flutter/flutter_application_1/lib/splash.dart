import 'package:flutter/material.dart';

class Splash extends StatelessWidget {
  const Splash({super.key});

  @override
  Widget build(BuildContext context) {
    return Material(child: Column(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [Image (image: AssetImage('logo.jpg'),
    ),
    Text("Crypto scanner",
    style:TextStyle(fontSize :32),
    ),

    ElevatedButton(onPressed: () =>{Navigator.pushNamed(context, "/home"),}, child:const Text("Start"),
    style:ElevatedButton.styleFrom(
      primary: Colors.blue,
      fixedSize: const Size(290,50),
      shape: new RoundedRectangleBorder(
               borderRadius: new BorderRadius.circular(30.0),

               ),)
 ,)],),);
  }
}